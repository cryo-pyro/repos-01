"""
Ukubona Renal Digital Twin — Python Pipeline
Master runner: executes all three steps in sequence.

Usage:
    cd ukubona_renal/
    pip install pandas numpy scipy matplotlib scikit-learn
    python python/run_pipeline.py

Directory structure after running:
    data/
        nhanes_raw_J.csv          — 2017-2018 NHANES cycle, merged
        nhanes_raw_P.csv          — 2019-2020 NHANES cycle, merged
        nhanes_pooled.csv         — both cycles combined
        nhanes_ckd_cohort.csv     — all adults with computable eGFR
        nhanes_black_ckd.csv      — Non-Hispanic Black subset
        kdigo_summary.csv         — KDIGO cell x KFRE summary table
        variance_components.csv   — sigma-squared by level
        kfre_calibration.csv      — KFRE percentile distribution
    figures/
        kdigo_heatmap.png
        variance_decomp.png

NHANES files auto-downloaded from CDC servers (~50MB total).

Key references:
    CKD-EPI 2021: Inker LA et al. NEJM 2021;385:1737-1749
    KFRE:         Tangri N et al. JAMA 2011;305:1553-1559
    KDIGO 2012:   Kidney Int Suppl 2013;3:1-150
    NHANES:       https://www.cdc.gov/nchs/nhanes/
"""

import sys, os, importlib.util

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

STEPS = [
    "01_nhanes_download_merge",
    "02_nhanes_clean_derive",
]

def main():
    print("=" * 60)
    print("  Ukubona Renal Digital Twin — Python Pipeline")
    print("=" * 60)
    base = os.path.dirname(os.path.abspath(__file__))
    for step in STEPS:
        path = os.path.join(base, f"{step}.py")
        if not os.path.exists(path):
            print(f"  [SKIP] {step}.py not found")
            continue
        print(f"\n[Step] {step}")
        spec = importlib.util.spec_from_file_location(step, path)
        mod  = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        mod.main()
        print(f"  checkmark {step} complete")

    print("\n" + "=" * 60)
    print("  Pipeline complete.")
    print("  Feed data/nhanes_black_ckd.csv into the JS twin widget")
    print("  to replace synthetic priors with real NHANES parameters.")
    print("=" * 60)

if __name__ == "__main__":
    main()
