"""
Ukubona Renal Digital Twin
Step 1: Download and merge NHANES 2017-2020 (pre-pandemic) public-use files
-----------------------------------------------------------------------
NHANES cycle: 2017-March 2020 (P cycle — largest pre-COVID cycle available)
Base URL: https://wwwn.cdc.gov/nchs/nhanes/2017-2018/ (J cycle)
      and https://wwwn.cdc.gov/nchs/nhanes/2019-2020/ (P cycle)

We pool both cycles (2017-2018 + 2019-2020) for maximum sample size.

File naming convention:
  DEMO_J.XPT  = demographics, 2017-2018 cycle
  DEMO_P.XPT  = demographics, 2019-2020 cycle
  (same pattern for all component files)

Output:
  data/nhanes_raw_J.csv   — 2017-2018 merged
  data/nhanes_raw_P.csv   — 2019-2020 merged
  data/nhanes_pooled.csv  — both cycles combined
"""

import os
import urllib.request
import pandas as pd
import numpy as np

BASE_DIR  = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR  = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

COMPONENTS = {
    "DEMO": {
        "desc": "Demographics",
        "vars": ["SEQN", "RIAGENDR", "RIDAGEYR", "RIDRETH3",
                 "WTMEC2YR", "SDMVPSU", "SDMVSTRA"]
    },
    "BIOPRO": {
        "desc": "Standard biochemistry profile (creatinine, albumin, etc.)",
        "vars": ["SEQN", "LBXSCR", "LBXSCA", "LBXSBU"]
    },
    "ALB_CR": {
        "desc": "Albumin-creatinine ratio (urine)",
        "vars": ["SEQN", "URXUMA", "URXUCR", "URXUAC"]
    },
    "BPX": {
        "desc": "Blood pressure examination",
        "vars": ["SEQN", "BPXSY1", "BPXDI1", "BPXSY2", "BPXDI2", "BPXSY3", "BPXDI3"]
    },
    "BMX": {
        "desc": "Body measures",
        "vars": ["SEQN", "BMXBMI", "BMXWT", "BMXHT"]
    },
    "DIQ": {
        "desc": "Diabetes questionnaire",
        "vars": ["SEQN", "DIQ010", "DIQ050", "DIQ070"]
    },
    "GHB": {
        "desc": "Glycohemoglobin",
        "vars": ["SEQN", "LBXGH"]
    },
    "BPQ": {
        "desc": "Blood pressure questionnaire",
        "vars": ["SEQN", "BPQ020", "BPQ040A"]
    },
    "SMQ": {
        "desc": "Smoking - cigarette use",
        "vars": ["SEQN", "SMQ020", "SMQ040"]
    },
    "KIQ_U": {
        "desc": "Kidney conditions - urology",
        "vars": ["SEQN", "KIQ022", "KIQ025"]
    },
}

CYCLES = {
    "J": "https://wwwn.cdc.gov/nchs/nhanes/2017-2018",
    "P": "https://wwwn.cdc.gov/nchs/nhanes/2019-2020",
}

def download_xpt(cycle_code, component, base_url):
    filename = f"{component}_{cycle_code}.XPT"
    url = f"{base_url}/{filename}"
    local_path = os.path.join(DATA_DIR, filename)
    if os.path.exists(local_path):
        print(f"  [cache] {filename}")
    else:
        print(f"  [download] {url}")
        try:
            urllib.request.urlretrieve(url, local_path)
        except Exception as e:
            print(f"  [WARN] Could not download {filename}: {e}")
            return None
    try:
        df = pd.read_sas(local_path, format="xport", encoding="utf-8")
        return df
    except Exception as e:
        print(f"  [WARN] Could not read {filename}: {e}")
        return None

def subset_vars(df, vars_needed):
    available = [v for v in vars_needed if v in df.columns]
    missing   = [v for v in vars_needed if v not in df.columns]
    if missing:
        print(f"    [note] variables not found (skipping): {missing}")
    return df[available].copy()

def build_cycle(cycle_code, base_url):
    print(f"\n{'='*60}")
    print(f"  Building cycle {cycle_code} ({base_url})")
    print(f"{'='*60}")
    frames = {}
    for component, meta in COMPONENTS.items():
        print(f"\n  Component: {component} — {meta['desc']}")
        df = download_xpt(cycle_code, component, base_url)
        if df is not None:
            frames[component] = subset_vars(df, meta["vars"])
            print(f"    rows={len(frames[component])}, cols={list(frames[component].columns)}")
    if "DEMO" not in frames:
        raise RuntimeError(f"DEMO file missing for cycle {cycle_code} — cannot proceed.")
    merged = frames["DEMO"].copy()
    for component, df in frames.items():
        if component == "DEMO":
            continue
        merged = merged.merge(df, on="SEQN", how="left")
    merged["CYCLE"] = cycle_code
    print(f"\n  Merged shape: {merged.shape}")
    return merged

def main():
    cycle_dfs = []
    for code, url in CYCLES.items():
        df = build_cycle(code, url)
        out = os.path.join(DATA_DIR, f"nhanes_raw_{code}.csv")
        df.to_csv(out, index=False)
        print(f"\n  Saved: {out}")
        cycle_dfs.append(df)
    pooled = pd.concat(cycle_dfs, ignore_index=True)
    out = os.path.join(DATA_DIR, "nhanes_pooled.csv")
    pooled.to_csv(out, index=False)
    print(f"\n  Pooled dataset saved: {out}")
    print(f"  Total rows: {len(pooled):,}")
    return pooled

if __name__ == "__main__":
    main()
