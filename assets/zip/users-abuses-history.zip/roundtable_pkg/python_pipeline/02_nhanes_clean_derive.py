"""
Ukubona Renal Digital Twin
Step 2: Clean raw NHANES data — derive CKD covariates — filter analytic cohort
-----------------------------------------------------------------------
Input:  data/nhanes_pooled.csv
Output: data/nhanes_ckd_cohort.csv   — all adults with eGFR computable
        data/nhanes_black_ckd.csv    — Non-Hispanic Black subset with CKD risk

Derived variables:
  eGFR      — CKD-EPI 2021 (race-free creatinine equation)
  SBP_mean  — mean of up to 3 readings
  uACR      — urinary albumin:creatinine ratio mg/g
  DM        — diabetes yes/no
  HTN       — hypertension yes/no
  Smk       — smoking status (never/former/current)
  KDIGO_G   — eGFR category G1-G5
  KDIGO_A   — uACR category A1-A3
  KFRE_5yr  — Tangri 4-variable 5-year ESRD risk

Key references:
  CKD-EPI 2021: Inker LA et al. NEJM 2021;385:1737-1749
  KFRE:         Tangri N et al. JAMA 2011;305:1553-1559
  KDIGO 2012:   Kidney Int Suppl 2013;3:1-150
"""

import os
import numpy as np
import pandas as pd

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

IN_FILE       = os.path.join(DATA_DIR, "nhanes_pooled.csv")
OUT_ALL       = os.path.join(DATA_DIR, "nhanes_ckd_cohort.csv")
OUT_BLACK_CKD = os.path.join(DATA_DIR, "nhanes_black_ckd.csv")


def ckd_epi_2021(scr, age, sex):
    """
    CKD-EPI 2021 race-free creatinine equation.
    Inker LA et al. NEJM 2021;385:1737-1749.
    sex: 1=Male, 2=Female (NHANES RIAGENDR coding)
    scr: serum creatinine mg/dL (LBXSCR)
    Returns eGFR ml/min/1.73m2
    """
    is_female = (sex == 2)
    kappa = np.where(is_female, 0.7, 0.9)
    alpha = np.where(is_female, -0.241, -0.302)
    ratio = scr / kappa
    egfr  = (142
             * np.where(ratio < 1, ratio ** alpha, 1.0)
             * np.where(ratio > 1, ratio ** -1.200, 1.0)
             * (0.9938 ** age))
    return pd.Series(egfr, index=scr.index)


def kfre_5yr(age, male, egfr, uacr):
    """
    Tangri KFRE 4-variable (creatinine-based).
    Tangri N et al. JAMA 2011;305:1553-1559.
    5-year risk = 1 - 0.9328^exp(LP)
    """
    uacr_safe = np.maximum(uacr, 0.1)
    lp = (-0.2201 * (age / 10 - 7.036)
          + 0.2467 * (male - 0.5642)
          - 0.5567 * (egfr / 5 - 7.222)
          + 0.4510 * (np.log(uacr_safe) - 5.137))
    risk = 1 - np.power(0.9328, np.exp(lp))
    return pd.Series(np.clip(risk, 0, 1), index=age.index)


def kdigo_g(egfr):
    cats = pd.cut(egfr,
                  bins=[-np.inf, 15, 30, 45, 60, 90, np.inf],
                  labels=["G5", "G4", "G3b", "G3a", "G2", "G1"])
    return cats.astype(str)


def kdigo_a(uacr):
    cats = pd.cut(uacr,
                  bins=[-np.inf, 30, 300, np.inf],
                  labels=["A1", "A2", "A3"])
    return cats.astype(str)


KDIGO_RISK_MAP = {
    ("G1","A1"):"Low",    ("G1","A2"):"Moderate",("G1","A3"):"High",
    ("G2","A1"):"Low",    ("G2","A2"):"Moderate",("G2","A3"):"High",
    ("G3a","A1"):"Moderate",("G3a","A2"):"High", ("G3a","A3"):"Very high",
    ("G3b","A1"):"High",  ("G3b","A2"):"High",   ("G3b","A3"):"Very high",
    ("G4","A1"):"Very high",("G4","A2"):"Very high",("G4","A3"):"Very high",
    ("G5","A1"):"Very high",("G5","A2"):"Very high",("G5","A3"):"Very high",
}


def kdigo_risk(g, a):
    return pd.Series(
        [KDIGO_RISK_MAP.get((gi, ai), "Unknown") for gi, ai in zip(g, a)],
        index=g.index
    )


def clean(df):
    d = df.copy()
    d["age"]      = pd.to_numeric(d.get("RIDAGEYR"), errors="coerce")
    d["sex"]      = pd.to_numeric(d.get("RIAGENDR"), errors="coerce")
    d["male"]     = (d["sex"] == 1).astype(int)
    d["race_eth"] = pd.to_numeric(d.get("RIDRETH3"), errors="coerce")
    d["race_label"] = d["race_eth"].map({
        1:"Hispanic", 2:"Hispanic", 3:"White",
        4:"Black", 6:"Asian", 7:"Other"
    }).fillna("Other")

    d["scr"]  = pd.to_numeric(d.get("LBXSCR"),  errors="coerce")
    d["uacr"] = pd.to_numeric(d.get("URXUAC"),  errors="coerce")
    if "URXUMA" in d.columns and "URXUCR" in d.columns:
        urxuma = pd.to_numeric(d["URXUMA"], errors="coerce")
        urxucr = pd.to_numeric(d["URXUCR"], errors="coerce")
        computed_uacr = (urxuma / urxucr) * 100
        d["uacr"] = d["uacr"].fillna(computed_uacr)

    valid_egfr_mask = d["scr"].notna() & d["age"].notna() & d["sex"].notna()
    d["egfr"] = np.nan
    d.loc[valid_egfr_mask, "egfr"] = ckd_epi_2021(
        d.loc[valid_egfr_mask, "scr"],
        d.loc[valid_egfr_mask, "age"],
        d.loc[valid_egfr_mask, "sex"]
    ).values

    for col in ["BPXSY1","BPXSY2","BPXSY3","BPXDI1","BPXDI2","BPXDI3"]:
        d[col] = pd.to_numeric(d.get(col), errors="coerce")
    d["sbp"] = d[["BPXSY1","BPXSY2","BPXSY3"]].mean(axis=1, skipna=True)
    d["dbp"] = d[["BPXDI1","BPXDI2","BPXDI3"]].mean(axis=1, skipna=True)

    d["bmi"]   = pd.to_numeric(d.get("BMXBMI"), errors="coerce")
    d["hba1c"] = pd.to_numeric(d.get("LBXGH"),  errors="coerce")

    diq010 = pd.to_numeric(d.get("DIQ010"), errors="coerce")
    d["dm"] = ((diq010 == 1) | (diq010 == 3)).astype(float)
    d.loc[diq010.isna(), "dm"] = np.nan

    bpq020 = pd.to_numeric(d.get("BPQ020"), errors="coerce")
    d["htn"] = ((bpq020 == 1) | (d["sbp"] >= 130)).astype(float)
    d.loc[bpq020.isna() & d["sbp"].isna(), "htn"] = np.nan

    smq020 = pd.to_numeric(d.get("SMQ020"), errors="coerce")
    smq040 = pd.to_numeric(d.get("SMQ040"), errors="coerce")
    d["smq020"] = smq020
    d["smq040"] = smq040
    def smoking_status(row):
        if row["smq020"] != 1: return "never"
        if row["smq040"] in [1, 2]: return "current"
        if row["smq040"] == 3: return "former"
        return np.nan
    d["smoking"] = d.apply(smoking_status, axis=1)
    d.drop(columns=["smq020","smq040"], inplace=True)

    d["kdigo_g"]    = kdigo_g(d["egfr"])
    d["kdigo_a"]    = kdigo_a(d["uacr"])
    d["kdigo_risk"] = kdigo_risk(d["kdigo_g"], d["kdigo_a"])

    kfre_mask = d["age"].notna() & d["egfr"].notna() & d["uacr"].notna()
    d["kfre_5yr"] = np.nan
    d.loc[kfre_mask, "kfre_5yr"] = kfre_5yr(
        d.loc[kfre_mask, "age"],
        d.loc[kfre_mask, "male"],
        d.loc[kfre_mask, "egfr"],
        d.loc[kfre_mask, "uacr"]
    ).values

    d["wt"]        = pd.to_numeric(d.get("WTMEC2YR"), errors="coerce")
    d["wt_pooled"] = d["wt"] / 2

    return d


def select_analytic_cols(d):
    keep = ["SEQN","CYCLE","age","male","sex","race_eth","race_label",
            "egfr","scr","uacr","sbp","dbp","bmi","hba1c",
            "dm","htn","smoking",
            "kdigo_g","kdigo_a","kdigo_risk","kfre_5yr",
            "wt","wt_pooled"]
    available = [c for c in keep if c in d.columns]
    return d[available].copy()


def main():
    print(f"Reading: {IN_FILE}")
    raw = pd.read_csv(IN_FILE, low_memory=False)
    print(f"  Raw shape: {raw.shape}")

    cleaned  = clean(raw)
    analytic = select_analytic_cols(cleaned)

    all_ckd = analytic[(analytic["age"] >= 18) & analytic["egfr"].notna()].copy()
    all_ckd.to_csv(OUT_ALL, index=False)
    print(f"\nAll adults with eGFR: n={len(all_ckd):,}")
    print(f"  Saved: {OUT_ALL}")

    black_ckd = all_ckd[all_ckd["race_label"] == "Black"].copy()
    black_ckd.to_csv(OUT_BLACK_CKD, index=False)
    print(f"\nNon-Hispanic Black with eGFR: n={len(black_ckd):,}")
    print(f"  Saved: {OUT_BLACK_CKD}")

    print("\n--- Black CKD subset: key descriptives ---")
    print(f"  Mean age:    {black_ckd['age'].mean():.1f} yrs")
    print(f"  % Male:      {black_ckd['male'].mean()*100:.1f}%")
    print(f"  Mean eGFR:   {black_ckd['egfr'].mean():.1f}")
    print(f"  Mean uACR:   {black_ckd['uacr'].mean():.1f} mg/g")
    print(f"  Mean SBP:    {black_ckd['sbp'].mean():.1f} mmHg")
    print(f"  Mean BMI:    {black_ckd['bmi'].mean():.1f}")
    print(f"  Mean HbA1c:  {black_ckd['hba1c'].mean():.1f}%")
    print(f"  % DM:        {black_ckd['dm'].mean()*100:.1f}%")
    print(f"  % HTN:       {black_ckd['htn'].mean()*100:.1f}%")
    print(f"  % Current smoker: {(black_ckd['smoking']=='current').mean()*100:.1f}%")
    print(f"  Mean KFRE 5yr: {black_ckd['kfre_5yr'].mean()*100:.1f}%")
    print(f"\n  KDIGO G distribution:\n{black_ckd['kdigo_g'].value_counts().sort_index()}")
    print(f"\n  KDIGO A distribution:\n{black_ckd['kdigo_a'].value_counts().sort_index()}")
    print(f"\n  KDIGO risk distribution:\n{black_ckd['kdigo_risk'].value_counts()}")

    return black_ckd


if __name__ == "__main__":
    main()
